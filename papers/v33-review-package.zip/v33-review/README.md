# Physics-only author-review and transition-order package

Start with papers/v33/REVISION-REPORT.md (historical v33 delivery), then
research/transition-order/RESULTS.md or transition-order-report.docx (continuation).
The paper remains an author-review draft; original figure/SM and specialist review
are still required. No transition-order or submission certification is implied.

From this extracted v33-review/ root:
  python3 -m pip install -r papers/v33/requirements.txt
  bash papers/v33/run_review_checks.sh

The current paper runner has 17+35+49=101 counted implementation/regression checks.
The full framework driver, unrelated theological/time-framework content and its
inputs are not needed or bundled. Full integrated-run logs may be included solely
as provenance; that full driver is available in the GitHub repository.

The bundle retains supplied A-1 manuscript/reviewer/credential-free assessment
inputs for source/hash reproduction; these are not claimed as agent creations.
The original v33 TeX and its historical tables are distinguished from the later
half-row data. Different finite-chi functionals must not be mixed silently.

Real MPS NPZ states are included selectively: controls and accepted immutable
anchors. Rolling/partial/warm-seed states are omitted here to avoid duplication;
the complete credential-scanned GitHub snapshot contains those records too.
Inspect metadata and optimizer tolerances: a checkpoint is not a phase verdict.

Optional workspace/amendment/publication helpers under research/ require the full
repository when their documented framework/Git inputs are referenced. They are
not part of the minimal physics verification command above.

SHA256SUMS hashes the supplied files. Source attributions/rights are retained.
