v33 author-review package

Open papers/v33/v33-revision-report.docx or papers/v33/REVISION-REPORT.md.
Full paper source: papers/v33/manuscript_revised_v33.tex.
Reproduction instructions: papers/v33/README.md.
This is not a phase-order or publication-readiness certificate.
